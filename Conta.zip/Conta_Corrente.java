public class ContaCorrente implements Conta{
    
    private double saldo;

    @Override
    public boolean saque(double valor){
        if(valor <= this.saldo){
            this.saldo -= valor;
            return true;
        }
        return false;
    }

    @Override
    public void deposito(double valor){
        saldo -= valor;
        valor -= (valor * 0.10);
    }

    @Override
    public double mostrarSaldo(){
        return this.saldo;
    }
}