public interface Conta {

    boolean saque(double valor);

    void deposito(double valor);

    double mostrarSaldo();

}
