import java.util.ArrayList;

public static void main(String[] args){

    Urna urna = new Urna();

    Candidato eleitor1 = new Eleitor('Vinicius','189465156651','5643616651','22/10/1992');
    Candidato eleitor2 = new Eleitor('Pedro','1894234651','23423616651','10/10/1997');
    Candidato eleitor3 = new Eleitor('Zezinho','423432426651','516343216651','12/09/1998');

    candidatura.registrarNumeroCandidato(25854);
    candidatura.registraCargo('Governador');

    candidatura.registrarNumeroCandidato(7485);
    candidatura.registraCargo('Governador');

    candidatura.registrarNumeroCandidato(97853);
    candidatura.registraCargo('Governador');

    candidatura.registrarNumeroCandidato(14);
    candidatura.registraCargo('Presidente');

    candidatura.registrarNumeroCandidato(26);
    candidatura.registraCargo('Presidente');

    candidatura.registrarNumeroCandidato(566);
    candidatura.registraCargo('Senador');

    voto.votar(25854,'Governador',566,'Senador',26,'Presidente');

    urna.quantidadeVotosCandidato();

    urna.mostraTotalVotos();

    urna.mostraQuantidadeNaoComputado();

}
