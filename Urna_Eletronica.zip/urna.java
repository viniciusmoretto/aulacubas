import java.util.ArrayList;

public class Urna{

    public int mostraTotalVotos(){

        return voto.quantidadeTotalVotos;

    }

    public int quantidadeVotosCandidato(){

        return candidato.quantidadeVotos;

    }

    public int mostraQuantidadeNaoComputado(){

        return voto.mostraQuantidadeNaoComputado;

    }

}