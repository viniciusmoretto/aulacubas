import java.util.ArrayList;

public class Voto{

    int quantidadeTotalVotos = 0;
    int quantidadeNaoComputado;

    ArrayList<String> candidatos = new ArrayList<String>();
        
        public void adicionarCandidatoLista(Candidato candidato){
          
          candidato.add(candidato);
          System.out.println(candidato);

        }

        public void removerCandidato(int indice){

            candidato.remove(indice);

        }

        public void limparCandidatos(){

            candidato.clear();

        }

        public void mostrarQuantidadeCandidatos(){

            candidato.size();

        }

        public void mostrarCandidatos(){

            for(int i = 1; i <= candidato.size();i++){

                candidato.get(i);

            }

        }

        public boolean votar(int voto1, String cargo1, int voto2, String cargo2, int voto3, String cargo3,){
        
                if(eleitor.voto == false || eleitor.voto2 == false || eleitor.voto3 == false){
                    for(int i = 0; i <= candidato.length(i); i++){
                        if(voto1 == candidato.numeroCandidato(i) && cargo1 == candidato.cargo(i)){
                            
                            candidato.quantidadeVotos(i)++;
                            this.quantidadeTotalVotos++;
                            eleitor.voto = true;
                        }
                        else{
                            eleitor.voto = false;
                            this.quantidadeNaoComputado++;
                        }

                        if(voto2 == candidato.numeroCandidato(i) && cargo2 == candidato.cargo(i)){
                            
                            candidato.quantidadeVotos(i)++;
                            this.quantidadeTotalVotos++;
                            eleitor.voto2 = true
                        }
                        else{
                            eleitor.voto2 = false;
                            this.quantidadeNaoComputado++;
                        }

                        if(voto3 == candidato.numeroCandidato(i) && cargo3 == candidato.cargo(i)){
                            
                            candidato.quantidadeVotos(i)++;
                            this.quantidadeTotalVotos++;
                            eleitor.voto3 = true;
                        }
                        else{
                            eleitor.voto3 = false;
                            this.quantidadeNaoComputado++;
                        }
                    }
                }
                else{
                    return false;
            }

        }

}

