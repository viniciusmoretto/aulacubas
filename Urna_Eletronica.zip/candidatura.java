import java.util.ArrayList;

public interface Candidatura{

    public void registrarNumeroCandidato(int numeroCandidato);

    public String registraCargo(String cargo);



}