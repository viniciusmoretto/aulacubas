import java.util.ArrayList;

public class Eleitor extends Pessoa{

    String tituloEleitor;
    boolean voto, voto2, voto3;


    public Eleitor(String nome, String cpf, String rg, String dataNascimento) {

        super(nome, cpf, rg, dataNascimento);

    }

}