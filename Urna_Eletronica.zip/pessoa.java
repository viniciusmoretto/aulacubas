import java.util.ArrayList;

public abstract class Pessoa{

    private String nome, cpf, rg, dataNascimento;

    public Pessoa(String nome, String cpf, String rg, String dataNascimento){

        this.nome = nome;
        this.cpf = cpf;
        this.rg = rg;
        this.dataNascimento = dataNascimento;

    }

}