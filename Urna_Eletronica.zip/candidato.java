import java.util.ArrayList;

public class Candidato extends Pessoa{

    int numeroCandidato;
    String cargo;
    int quantidadeVotos;
    

    Eleitor el1 = new Eleitor;

    public void registrarNumeroCandidato(int numeroCandidato){

        this.numeroCandidato = numeroCandidato;

    }

    public void registraCargo(String cargo){
    
        this.cargo = cargo;

    }

}