import java.util.ArrayList;

public class BancoBrasil
{
	
    private ArrayList<ContaEstudante> constasEstudante = new ArrayList();
    private ArrayList<ContaCorrente> contasCorrente = new ArrayList();
    
    public void addContaEstudante(ContaEstudante conta){
        constasEstudante.add(conta);
    }
    
    public void addContaCorrente(ContaCorrente conta) {
    	contasCorrente.add(conta);
    }
    
    public ArrayList<ContaEstudante> ContasEstudante(){
        return this.constasEstudante;
    }
    
    
    public double saldoTotal(){
    	double somatoria = 0;
        
    	for(int i = 0; i < constasEstudante.size(); i ++) {	
        	ContaEstudante ContasE = constasEstudante.get(i);
        	somatoria += ContasE.pegaSaldo();
        }
    	
    	for(int i = 0; i <contasCorrente.size(); i++) {
    		ContaCorrente ContasC = contasCorrente.get(i);
    		somatoria += ContasC.pegaSaldo();
    	}
    	
        return somatoria;
    }
   
}