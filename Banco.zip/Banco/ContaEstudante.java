public class ContaEstudante extends Conta
{
	public ContaEstudante(){
        super(400.0);
    }
}
