public class TesteBancoBrasil
{
    public static void main(){
        BancoBrasil banco = new BancoBrasil();
        
        ContaEstudante ce1 = new ContaEstudante();
        banco.addContaEstudante(ce1);
        
        ContaCorrente cc1 = new ContaCorrente();
        banco.addContaCorrente(cc1);
        
        System.out.println(banco.ContasEstudante().size());
        
    }
}
